﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LOC
{
    public partial class frm_AboutUs : Form
    {
        public frm_AboutUs()
        {
            InitializeComponent();
        }
    }
}
