﻿namespace LOC
{
    partial class frm_MainFP
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lb_Result = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.btn_export = new System.Windows.Forms.Button();
            this.btn_deleteAll = new System.Windows.Forms.Button();
            this.btn_FP = new System.Windows.Forms.Button();
            this.txt_EIFs_Complex = new System.Windows.Forms.TextBox();
            this.txt_ILFs_Complex = new System.Windows.Forms.TextBox();
            this.txt_EQs_Complex = new System.Windows.Forms.TextBox();
            this.txt_OIs_Complex = new System.Windows.Forms.TextBox();
            this.txt_EIs_Complex = new System.Windows.Forms.TextBox();
            this.txt_EIFs_Average = new System.Windows.Forms.TextBox();
            this.txt_ILFs_Average = new System.Windows.Forms.TextBox();
            this.txt_EQs_Average = new System.Windows.Forms.TextBox();
            this.txt_OIs_Average = new System.Windows.Forms.TextBox();
            this.txt_EIs_Average = new System.Windows.Forms.TextBox();
            this.txt_EIFs_Simple = new System.Windows.Forms.TextBox();
            this.txt_ILFs_Simple = new System.Windows.Forms.TextBox();
            this.txt_EQs_Simple = new System.Windows.Forms.TextBox();
            this.txt_OIs_Simple = new System.Windows.Forms.TextBox();
            this.txt_EIs_Simple = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(101, 74);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(224, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "MEASUREMENT PARAMETER";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(460, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(224, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "MEASUREMENT PARAMETER";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(437, 99);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "Simple";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(534, 99);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(68, 17);
            this.label4.TabIndex = 3;
            this.label4.Text = "Average";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(639, 99);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(68, 17);
            this.label5.TabIndex = 4;
            this.label5.Text = "Complex";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lb_Result);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.btn_export);
            this.groupBox1.Controls.Add(this.btn_deleteAll);
            this.groupBox1.Controls.Add(this.btn_FP);
            this.groupBox1.Controls.Add(this.txt_EIFs_Complex);
            this.groupBox1.Controls.Add(this.txt_ILFs_Complex);
            this.groupBox1.Controls.Add(this.txt_EQs_Complex);
            this.groupBox1.Controls.Add(this.txt_OIs_Complex);
            this.groupBox1.Controls.Add(this.txt_EIs_Complex);
            this.groupBox1.Controls.Add(this.txt_EIFs_Average);
            this.groupBox1.Controls.Add(this.txt_ILFs_Average);
            this.groupBox1.Controls.Add(this.txt_EQs_Average);
            this.groupBox1.Controls.Add(this.txt_OIs_Average);
            this.groupBox1.Controls.Add(this.txt_EIs_Average);
            this.groupBox1.Controls.Add(this.txt_EIFs_Simple);
            this.groupBox1.Controls.Add(this.txt_ILFs_Simple);
            this.groupBox1.Controls.Add(this.txt_EQs_Simple);
            this.groupBox1.Controls.Add(this.txt_OIs_Simple);
            this.groupBox1.Controls.Add(this.txt_EIs_Simple);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(134, 23);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(849, 613);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Function Point";
            // 
            // lb_Result
            // 
            this.lb_Result.AutoSize = true;
            this.lb_Result.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Result.Location = new System.Drawing.Point(510, 444);
            this.lb_Result.Name = "lb_Result";
            this.lb_Result.Size = new System.Drawing.Size(0, 17);
            this.lb_Result.TabIndex = 29;
            this.lb_Result.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(422, 444);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(54, 17);
            this.label11.TabIndex = 28;
            this.label11.Text = "Result";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btn_export
            // 
            this.btn_export.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(119)))), ((int)(((byte)(53)))), ((int)(((byte)(252)))));
            this.btn_export.FlatAppearance.BorderSize = 0;
            this.btn_export.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_export.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_export.ForeColor = System.Drawing.Color.White;
            this.btn_export.Location = new System.Drawing.Point(571, 496);
            this.btn_export.Name = "btn_export";
            this.btn_export.Size = new System.Drawing.Size(113, 33);
            this.btn_export.TabIndex = 27;
            this.btn_export.Text = "Export";
            this.btn_export.UseVisualStyleBackColor = false;
            this.btn_export.Click += new System.EventHandler(this.btn_export_Click);
            // 
            // btn_deleteAll
            // 
            this.btn_deleteAll.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(119)))), ((int)(((byte)(53)))), ((int)(((byte)(252)))));
            this.btn_deleteAll.FlatAppearance.BorderSize = 0;
            this.btn_deleteAll.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_deleteAll.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_deleteAll.ForeColor = System.Drawing.Color.White;
            this.btn_deleteAll.Location = new System.Drawing.Point(152, 496);
            this.btn_deleteAll.Name = "btn_deleteAll";
            this.btn_deleteAll.Size = new System.Drawing.Size(118, 33);
            this.btn_deleteAll.TabIndex = 26;
            this.btn_deleteAll.Text = "Delete All";
            this.btn_deleteAll.UseVisualStyleBackColor = false;
            this.btn_deleteAll.Click += new System.EventHandler(this.btn_deleteAll_Click);
            // 
            // btn_FP
            // 
            this.btn_FP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(119)))), ((int)(((byte)(53)))), ((int)(((byte)(252)))));
            this.btn_FP.FlatAppearance.BorderSize = 0;
            this.btn_FP.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_FP.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_FP.ForeColor = System.Drawing.Color.White;
            this.btn_FP.Location = new System.Drawing.Point(366, 496);
            this.btn_FP.Name = "btn_FP";
            this.btn_FP.Size = new System.Drawing.Size(113, 33);
            this.btn_FP.TabIndex = 25;
            this.btn_FP.Text = "Count";
            this.btn_FP.UseVisualStyleBackColor = false;
            this.btn_FP.Click += new System.EventHandler(this.btn_FP_Click);
            // 
            // txt_EIFs_Complex
            // 
            this.txt_EIFs_Complex.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_EIFs_Complex.Location = new System.Drawing.Point(639, 382);
            this.txt_EIFs_Complex.Name = "txt_EIFs_Complex";
            this.txt_EIFs_Complex.Size = new System.Drawing.Size(68, 34);
            this.txt_EIFs_Complex.TabIndex = 23;
            this.txt_EIFs_Complex.TextChanged += new System.EventHandler(this.txt_EIs_Simple_TextChanged);
            this.txt_EIFs_Complex.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_EIs_Simple_KeyPress);
            // 
            // txt_ILFs_Complex
            // 
            this.txt_ILFs_Complex.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ILFs_Complex.Location = new System.Drawing.Point(639, 327);
            this.txt_ILFs_Complex.Name = "txt_ILFs_Complex";
            this.txt_ILFs_Complex.Size = new System.Drawing.Size(68, 34);
            this.txt_ILFs_Complex.TabIndex = 22;
            this.txt_ILFs_Complex.TextChanged += new System.EventHandler(this.txt_EIs_Simple_TextChanged);
            this.txt_ILFs_Complex.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_EIs_Simple_KeyPress);
            // 
            // txt_EQs_Complex
            // 
            this.txt_EQs_Complex.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_EQs_Complex.Location = new System.Drawing.Point(639, 269);
            this.txt_EQs_Complex.Name = "txt_EQs_Complex";
            this.txt_EQs_Complex.Size = new System.Drawing.Size(68, 34);
            this.txt_EQs_Complex.TabIndex = 21;
            this.txt_EQs_Complex.TextChanged += new System.EventHandler(this.txt_EIs_Simple_TextChanged);
            this.txt_EQs_Complex.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_EIs_Simple_KeyPress);
            // 
            // txt_OIs_Complex
            // 
            this.txt_OIs_Complex.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_OIs_Complex.Location = new System.Drawing.Point(639, 216);
            this.txt_OIs_Complex.Name = "txt_OIs_Complex";
            this.txt_OIs_Complex.Size = new System.Drawing.Size(68, 34);
            this.txt_OIs_Complex.TabIndex = 20;
            this.txt_OIs_Complex.TextChanged += new System.EventHandler(this.txt_EIs_Simple_TextChanged);
            this.txt_OIs_Complex.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_EIs_Simple_KeyPress);
            // 
            // txt_EIs_Complex
            // 
            this.txt_EIs_Complex.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_EIs_Complex.Location = new System.Drawing.Point(639, 163);
            this.txt_EIs_Complex.Name = "txt_EIs_Complex";
            this.txt_EIs_Complex.Size = new System.Drawing.Size(68, 34);
            this.txt_EIs_Complex.TabIndex = 19;
            this.txt_EIs_Complex.TextChanged += new System.EventHandler(this.txt_EIs_Simple_TextChanged);
            this.txt_EIs_Complex.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_EIs_Simple_KeyPress);
            // 
            // txt_EIFs_Average
            // 
            this.txt_EIFs_Average.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_EIFs_Average.Location = new System.Drawing.Point(537, 382);
            this.txt_EIFs_Average.Name = "txt_EIFs_Average";
            this.txt_EIFs_Average.Size = new System.Drawing.Size(68, 34);
            this.txt_EIFs_Average.TabIndex = 18;
            this.txt_EIFs_Average.TextChanged += new System.EventHandler(this.txt_EIs_Simple_TextChanged);
            this.txt_EIFs_Average.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_EIs_Simple_KeyPress);
            // 
            // txt_ILFs_Average
            // 
            this.txt_ILFs_Average.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ILFs_Average.Location = new System.Drawing.Point(537, 327);
            this.txt_ILFs_Average.Name = "txt_ILFs_Average";
            this.txt_ILFs_Average.Size = new System.Drawing.Size(68, 34);
            this.txt_ILFs_Average.TabIndex = 17;
            this.txt_ILFs_Average.TextChanged += new System.EventHandler(this.txt_EIs_Simple_TextChanged);
            this.txt_ILFs_Average.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_EIs_Simple_KeyPress);
            // 
            // txt_EQs_Average
            // 
            this.txt_EQs_Average.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_EQs_Average.Location = new System.Drawing.Point(537, 269);
            this.txt_EQs_Average.Name = "txt_EQs_Average";
            this.txt_EQs_Average.Size = new System.Drawing.Size(68, 34);
            this.txt_EQs_Average.TabIndex = 16;
            this.txt_EQs_Average.TextChanged += new System.EventHandler(this.txt_EIs_Simple_TextChanged);
            this.txt_EQs_Average.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_EIs_Simple_KeyPress);
            // 
            // txt_OIs_Average
            // 
            this.txt_OIs_Average.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_OIs_Average.Location = new System.Drawing.Point(537, 216);
            this.txt_OIs_Average.Name = "txt_OIs_Average";
            this.txt_OIs_Average.Size = new System.Drawing.Size(68, 34);
            this.txt_OIs_Average.TabIndex = 15;
            this.txt_OIs_Average.TextChanged += new System.EventHandler(this.txt_EIs_Simple_TextChanged);
            this.txt_OIs_Average.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_EIs_Simple_KeyPress);
            // 
            // txt_EIs_Average
            // 
            this.txt_EIs_Average.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_EIs_Average.Location = new System.Drawing.Point(537, 163);
            this.txt_EIs_Average.Name = "txt_EIs_Average";
            this.txt_EIs_Average.Size = new System.Drawing.Size(68, 34);
            this.txt_EIs_Average.TabIndex = 14;
            this.txt_EIs_Average.TextChanged += new System.EventHandler(this.txt_EIs_Simple_TextChanged);
            this.txt_EIs_Average.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_EIs_Simple_KeyPress);
            // 
            // txt_EIFs_Simple
            // 
            this.txt_EIFs_Simple.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_EIFs_Simple.Location = new System.Drawing.Point(425, 382);
            this.txt_EIFs_Simple.Name = "txt_EIFs_Simple";
            this.txt_EIFs_Simple.Size = new System.Drawing.Size(68, 34);
            this.txt_EIFs_Simple.TabIndex = 13;
            this.txt_EIFs_Simple.TextChanged += new System.EventHandler(this.txt_EIs_Simple_TextChanged);
            this.txt_EIFs_Simple.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_EIs_Simple_KeyPress);
            // 
            // txt_ILFs_Simple
            // 
            this.txt_ILFs_Simple.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ILFs_Simple.Location = new System.Drawing.Point(425, 327);
            this.txt_ILFs_Simple.Name = "txt_ILFs_Simple";
            this.txt_ILFs_Simple.Size = new System.Drawing.Size(68, 34);
            this.txt_ILFs_Simple.TabIndex = 12;
            this.txt_ILFs_Simple.TextChanged += new System.EventHandler(this.txt_EIs_Simple_TextChanged);
            this.txt_ILFs_Simple.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_EIs_Simple_KeyPress);
            // 
            // txt_EQs_Simple
            // 
            this.txt_EQs_Simple.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_EQs_Simple.Location = new System.Drawing.Point(425, 269);
            this.txt_EQs_Simple.Name = "txt_EQs_Simple";
            this.txt_EQs_Simple.Size = new System.Drawing.Size(68, 34);
            this.txt_EQs_Simple.TabIndex = 11;
            this.txt_EQs_Simple.TextChanged += new System.EventHandler(this.txt_EIs_Simple_TextChanged);
            this.txt_EQs_Simple.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_EIs_Simple_KeyPress);
            // 
            // txt_OIs_Simple
            // 
            this.txt_OIs_Simple.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_OIs_Simple.Location = new System.Drawing.Point(425, 216);
            this.txt_OIs_Simple.Name = "txt_OIs_Simple";
            this.txt_OIs_Simple.Size = new System.Drawing.Size(68, 34);
            this.txt_OIs_Simple.TabIndex = 10;
            this.txt_OIs_Simple.TextChanged += new System.EventHandler(this.txt_EIs_Simple_TextChanged);
            this.txt_OIs_Simple.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_EIs_Simple_KeyPress);
            // 
            // txt_EIs_Simple
            // 
            this.txt_EIs_Simple.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_EIs_Simple.Location = new System.Drawing.Point(425, 163);
            this.txt_EIs_Simple.Name = "txt_EIs_Simple";
            this.txt_EIs_Simple.Size = new System.Drawing.Size(68, 34);
            this.txt_EIs_Simple.TabIndex = 9;
            this.txt_EIs_Simple.TextChanged += new System.EventHandler(this.txt_EIs_Simple_TextChanged);
            this.txt_EIs_Simple.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_EIs_Simple_KeyPress);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(101, 398);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(272, 17);
            this.label10.TabIndex = 8;
            this.label10.Text = "Number of External Interfaces (EIFs)";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(101, 343);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(169, 17);
            this.label9.TabIndex = 7;
            this.label9.Text = "Number of Files (ILFs)";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(101, 232);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(225, 17);
            this.label8.TabIndex = 6;
            this.label8.Text = "Number of Use Outputs (EOs)";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(101, 179);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(196, 17);
            this.label7.TabIndex = 5;
            this.label7.Text = "Number of Use Input (EIs)";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(101, 285);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(236, 17);
            this.label6.TabIndex = 5;
            this.label6.Text = "Number of User Inquiries (EQs)";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // frm_MainFP
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1081, 671);
            this.Controls.Add(this.groupBox1);
            this.Name = "frm_MainFP";
            this.Text = "frm_MainFP";
            this.Load += new System.EventHandler(this.frm_MainFP_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txt_EIFs_Complex;
        private System.Windows.Forms.TextBox txt_ILFs_Complex;
        private System.Windows.Forms.TextBox txt_EQs_Complex;
        private System.Windows.Forms.TextBox txt_OIs_Complex;
        private System.Windows.Forms.TextBox txt_EIs_Complex;
        private System.Windows.Forms.TextBox txt_EIFs_Average;
        private System.Windows.Forms.TextBox txt_ILFs_Average;
        private System.Windows.Forms.TextBox txt_EQs_Average;
        private System.Windows.Forms.TextBox txt_OIs_Average;
        private System.Windows.Forms.TextBox txt_EIs_Average;
        private System.Windows.Forms.TextBox txt_EIFs_Simple;
        private System.Windows.Forms.TextBox txt_ILFs_Simple;
        private System.Windows.Forms.TextBox txt_EQs_Simple;
        private System.Windows.Forms.TextBox txt_OIs_Simple;
        private System.Windows.Forms.TextBox txt_EIs_Simple;
        private System.Windows.Forms.Button btn_FP;
        private System.Windows.Forms.Button btn_export;
        private System.Windows.Forms.Button btn_deleteAll;
        private System.Windows.Forms.Label lb_Result;
        private System.Windows.Forms.Label label11;
    }
}