﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaiTapNgay30_1_2024
{
    internal class SinhVienKCNTT
    {
        private string mssv;
        private string hoten;
        private string diachi;
        private DateTime ngaysinh;
        private float diemcs414;
        private float diemis311;
        private float diemcs311;

        public string Mssv { get => mssv; set => mssv = value; }
        public string Hoten { get => hoten; set => hoten = value; }
        public string Diachi { get => diachi; set => diachi = value; }
        public DateTime Ngaysinh { get => ngaysinh; set => ngaysinh = value; }
        public float Diemcs414 { get => diemcs414; set => diemcs414 = value; }
        public float Diemis311 { get => diemis311; set => diemis311 = value; }
        public float Diemcs311 { get => diemcs311; set => diemcs311 = value; }

        public SinhVienKCNTT()
        {

        }
        public virtual double diemtb()
        {
            return (Diemcs311 + Diemcs414 + Diemis311) / 3;
        }

        public virtual void Nhap()
        {
            Console.Write("\nNhap ma so sinh vien: ");
            Mssv = Console.ReadLine();
            Console.Write("\nNhap Ho ten: ");
            Hoten = Console.ReadLine();
            Console.Write("\nNhap dia chi: ");
            Diachi = Console.ReadLine();
            try
            {
                string input;
                Console.Write("\nNhap ngay thang nam sinh: ");
                input = Console.ReadLine();
                Ngaysinh = DateTime.ParseExact(input, "mm/dd/yy", null);
            }
            catch (FormatException)
            {
                Console.Write("\nNgay sinh sai hoac khong dung dinh dang, vui long nhap lai!!");
            }
            Console.Write("\nNhap diem CS414: ");
            Diemcs414 = float.Parse(Console.ReadLine());
            Console.Write("\nNhap diem CS311: ");
            Diemcs311 = float.Parse(Console.ReadLine());
            Console.Write("\nNhap diem IS311: ");
            Diemis311 = float.Parse(Console.ReadLine());
        }

        public virtual float TinhXepLoai()
        {
            while (diemtb() >= 0 && diemtb() <= 10)
            {
                if (diemtb() >= 8)
                {
                    Console.Write("\nBan xep loai gioi!!!♥");
                }
                else if (diemtb() >= 6.5)
                {
                    Console.Write("\nBan xep loai kha!!!");
                }
                else if (diemtb() >= 5)
                {
                    Console.Write("\nBan xep loai trung binh!!!");
                }
                else
                {
                    Console.Write("\nBan xep lai yeu!!!");
                }
            }
            return 0;
        }

        public virtual void Xuat()
        { 
            Console.Write($"\nHo ten: {Hoten} \nMa so sinh vien: {Mssv} \nDia chi: {Diachi} \nNgay sinh: {Ngaysinh} \nDiemCS411 {Diemcs414} \nnDiemIS311: {Diemis311} \nDiemCS311: {Diemcs311}");
            Console.Write("\nDiem trung binh: {0} ", diemtb());
        }
    }
}
